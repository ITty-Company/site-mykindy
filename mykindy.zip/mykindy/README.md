# MyKindy — сайт (@mykindy_story, персональні книги · тільки українська)

Статичний сайт для Cloudflare Workers (лише assets). Ідея: «Мамо, я заліз у книжку!». Одна real-time 3D-сцена «Книга-розкладачка»
(three.js r170, усе процедурно, без моделей і фото): книга на в'язаному пледі, обкладинка з тисненим змієм і рамкою «Тут буде ім'я»,
5 паперових pop-up шарів-продуктів (фігурка-герой із банером імені, казковий замок, абетка-кубики з іменем, цифри 1 2 3 з кнопками,
подарунковий пакет зі стрічкою), змій із хвостом і бантиками, нитка з гірляндою. Ім'я, вписане на сайті, стає 3D-літерами на обкладинці.
Скрол = одна чиста `pose(p)`; скрол назад відновлює кожен кадр.

## Структура
- `public/` — увесь сайт: `index.html`, `knyhy.html` (Книги), `zamovyty.html` (конструктор замовлення), `podarunok.html`, `pro-nas.html`,
  `kontakty.html`, `404.html`, `favicon.svg`, `assets/img/og.jpg`, `assets/img/poster.webp` (кадр для браузерів без WebGL2).
- `public/assets/js/` — `choreo.js` (SEGS, `pose(p)`, камера — чисті функції), `book.js` (модель і світ), `textures.js` (canvas-текстури),
  `glyphs.js` (контури Montserrat Alternates 800, `_notes/make_glyphs.py`), `scene.js` (renderer, світло день→ніч, bloom + grade, якість, DPR),
  `app.js` (головна: прелоадер, скрол, виноски, кроки, `?p=` / `?demo=1` / `?pre=1` / `?q=` / `?clean` / `?name=`),
  `page.js` (внутрішні сторінки, ефекти секцій, конструктор), `common.js` (шапка, курсор «Змійок», «Розкладачка», шторка «Хвіст змія», футер).
- `public/assets/vendor/` — three.js r170 (+ addons), GSAP 3.15 (ScrollTrigger, DrawSVG, ScrambleText), Lenis 1.3 — локально.
  Шрифти Montserrat Alternates, Kurale, Mulish — self-host woff2 (OFL). Жодних запитів на чужі домени.
- `_notes/build.py` + `_notes/content.py` — усі тексти → HTML: `python3 _notes/build.py`.
- `_notes/test-choreo.mjs` (`node _notes/test-choreo.mjs`), `_notes/check.py`, `_notes/shoot.py`, `_notes/demo_video.py` — перевірки й скріншоти (Playwright).

## Локально
```bash
python3 -m http.server -d public 8790   # → http://127.0.0.1:8790/
```

## Публікація
```bash
npx wrangler login      # один раз
npx wrangler deploy     # з цієї папки
```

## Конструктор замовлення
`/zamovyty`: ім'я дитини → книга (4 види) → сайт складає текст повідомлення; «Скопіювати текст», «Відкрити Telegram» (t.me/mykindy_story),
«Instagram Direct» (ig.me/m/mykindy_story). Сайт нічого не надсилає сам. Цін на сайті немає — «Ціну та деталі уточнимо в Telegram».

## Уточнити в клієнтки (на сайті нейтрально або не згадано)
- Ціни, терміни виготовлення, доставка, місто, формат/кількість сторінок (FAQ на /zamovyty відповідає «уточнимо в Telegram»).
- Друге посилання в біо Instagram (невідоме), чи t.me/mykindy_story — канал чи особистий акаунт.
- Дозвіл на реальні фото книг/пакування з Instagram (зараз усе процедурне), фото засновниці @yak_ilona.
- Чи можна цитувати відгуки з хайлайту «Відгуки» (зараз лише посилання).
- Домен (canonical/OG зараз https://mykindy.pages.dev).
