# python3 _notes/check.py — консоль усіх сторінок, горизонтальний скрол 390/768/1440, зовнішні запити, обратимість реального скролу,
# шторка між сторінками, конструктор, reduced-motion, меню, слова «демо/lorem/TODO». Mac Chrome: CH=1; інакше — вбудований Chromium.
import time, json, os
from playwright.sync_api import sync_playwright
B = os.environ.get('BASE', 'http://127.0.0.1:8790/')
PAGES = ['index', 'knyhy', 'zamovyty', 'podarunok', 'pro-nas', 'kontakty', '404']
MAC = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
logs = []
SIG = '''JSON.stringify((()=>{const W=window.__scene.world;const r=[];W.root.traverse(o=>{if(o.isMesh||o.isGroup){let v=o.visible,q=o.parent;while(q){v=v&&q.visible;q=q.parent}r.push(v?1:0);if(v&&o!==W.book)r.push(...o.position.toArray().map(v=>+v.toFixed(2)),...o.rotation.toArray().slice(0,3).map(v=>+(+v).toFixed(2)))}});return r})())'''
with sync_playwright() as pw:
    if os.environ.get('CH'): br = pw.chromium.launch(executable_path=MAC, headless=True, args=['--use-angle=metal', '--enable-gpu', '--ignore-gpu-blocklist'])
    else: br = pw.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
    def mk(w, h, mob=False, rm=False):
        c = br.new_context(viewport={'width': w, 'height': h}, device_scale_factor=1, is_mobile=mob, has_touch=mob, reduced_motion='reduce' if rm else 'no-preference')
        p = c.new_page()
        p.on('console', lambda m: logs.append(f'[{m.type}] {p.url} {m.text[:300]}') if m.type in ('error', 'warning') and 'GPU stall' not in m.text and 'GL Driver' not in m.text else None)
        p.on('pageerror', lambda e: logs.append(f'[pageerror] {p.url} {str(e)[:300]}'))
        p.on('response', lambda r: logs.append(f'[{r.status}] {r.url}') if r.status >= 400 and not r.url.endswith('/nope.html') else None)
        p.on('request', lambda r: logs.append(f'[extern] {r.url}') if not r.url.startswith(B) and not r.url.startswith('data:') and not r.url.startswith('blob:') else None)
        return c, p
    for w, h, mob in [(1440, 900, False), (768, 1024, True), (390, 844, True)]:
        c, p = mk(w, h, mob)
        for pg in PAGES:
            p.goto(f'{B}{pg}.html'); time.sleep(2.5)
            sw = p.evaluate('document.documentElement.scrollWidth')
            if sw > w: logs.append(f'[overflow] {pg} {w}: {sw}')
            p.evaluate('window.scrollTo(0, document.body.scrollHeight)'); time.sleep(0.8)
            sw = p.evaluate('document.documentElement.scrollWidth')
            if sw > w: logs.append(f'[overflow-bottom] {pg} {w}: {sw}')
            t = p.inner_text('body').lower()
            for bad in ['демо', 'lorem', 'todo', 'placeholder', 'undefined']:
                if bad in t: logs.append(f'[word {bad}] {pg} {w}')
        c.close()
    print('pages/overflow done', flush=True)
    c, p = mk(1440, 900)
    p.goto(B + 'nope.html'); time.sleep(1); print('404 status page title:', p.title())
    p.goto(B + 'index.html'); p.wait_for_function('window.__scene && window.__fps>0', timeout=120000); time.sleep(8)
    p.mouse.move(5, 5); time.sleep(0.5)
    a = p.evaluate(SIG)
    H = p.evaluate('document.getElementById("spacer").offsetHeight')
    for y in range(0, H, 900): p.mouse.wheel(0, 900); time.sleep(0.05)
    time.sleep(3); mid = p.evaluate(SIG)
    for y in range(0, H + 3000, 900): p.mouse.wheel(0, -900); time.sleep(0.05)
    time.sleep(8); b = p.evaluate(SIG)
    print('reversible:', a == b, '| changed at end:', a != mid, flush=True)
    if a != b:
        A = json.loads(a); Bv = json.loads(b); print([(i, x, y) for i, (x, y) in enumerate(zip(A, Bv)) if x != y][:6])
    print('name→3D:', p.evaluate('(()=>{const i=document.getElementById("hero-name");i.value="Тарас";i.dispatchEvent(new Event("input"));return window.__scene.world.name})()'))
    c.close()
    c, p = mk(1440, 900); p.goto(B + 'knyhy.html'); time.sleep(3)
    p.click('.hd-nav a[href="kontakty.html"]'); time.sleep(3.5); print('curtain nav →', p.url.split('/')[-1], '| tail visible:', p.evaluate('document.querySelector(".tail").classList.contains("run")'))
    c.close()
    c, p = mk(390, 844, True, True); p.goto(B + 'index.html'); time.sleep(5)
    print('reduced: locked=', p.evaluate('document.body.classList.contains("is-locked")'), 'pre=', p.evaluate('!!document.getElementById("pre")'), 'scene=', p.evaluate('!!window.__scene'))
    p.click('.menu-btn'); time.sleep(0.3); print('menu open:', p.is_visible('#menu'), p.get_attribute('.menu-btn', 'aria-expanded'))
    c.close()
    br.close()
print('LOGS', len(logs)); print('\n'.join(dict.fromkeys(logs)))
