# python3 _notes/shoot.py [what] — Playwright: скріншоти (deviceScaleFactor 1) → _notes/<OUTD|review1>/ + лог консолі
# what: shots | pages | x <p,p,..> | m <p,p> | pre | all.  Сервер: python3 -m http.server -d public 8790
# Mac Chrome: CH=1 (Metal). Без CH — вбудований Chromium (swiftshader).
import sys, time, os
from playwright.sync_api import sync_playwright
BASE = os.environ.get('BASE', 'http://127.0.0.1:8790/')
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), os.environ.get('OUTD', 'review1'))
os.makedirs(OUT, exist_ok=True)
MAC = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
what = sys.argv[1] if len(sys.argv) > 1 else 'all'
logs = []
with sync_playwright() as pw:
    if os.environ.get('CH'): br = pw.chromium.launch(executable_path=MAC, headless=True, args=['--use-angle=metal', '--enable-gpu', '--ignore-gpu-blocklist'])
    else: br = pw.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
    def page(w, h, mobile=False):
        ctx = br.new_context(viewport={'width': w, 'height': h}, device_scale_factor=1, is_mobile=mobile, has_touch=mobile)
        pg = ctx.new_page()
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text[:300]}') if m.type in ('error', 'warning') and 'GL Driver' not in m.text and 'GPU stall' not in m.text else None)
        pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
        pg.on('requestfailed', lambda r: logs.append(f'[reqfail] {r.url}'))
        pg.on('response', lambda r: logs.append(f'[{r.status}] {r.url}') if r.status >= 400 else None)
        return ctx, pg
    def idx(pg, p, name='Марта'):
        pg.goto(f'{BASE}index.html?p={p}&name={name}'); pg.wait_for_function('window.__scene && window.__fps>0', timeout=120000); time.sleep(1.5)
    if what in ('all', 'shots'):
        ctx, pg = page(1440, 900)
        for p in [0, 0.19, 0.28, 0.388, 0.44, 0.492, 0.544, 0.596, 0.66, 0.745, 0.85, 1]:
            idx(pg, p); pg.screenshot(path=f'{OUT}/d-{p:.3f}.png')
        ctx.close()
        ctx, pg = page(390, 844, True)
        for p in [0, 0.28, 0.44, 0.66, 0.85, 1]:
            idx(pg, p); pg.screenshot(path=f'{OUT}/m-{p:.3f}.png')
        ctx.close()
    if what in ('all', 'pages'):
        for name in ['knyhy', 'zamovyty', 'podarunok', 'pro-nas', 'kontakty', '404']:
            ctx, pg = page(1440, 900)
            pg.goto(f'{BASE}{name}.html'); time.sleep(4)
            pg.screenshot(path=f'{OUT}/i-{name}.png')
            secs = pg.evaluate('[...document.querySelectorAll("main > .sec")].map(s=>s.getBoundingClientRect().top+scrollY)')
            for k, y in enumerate(secs[:4]):
                pg.evaluate(f'(window.__lenis&&window.__lenis.scrollTo({int(y)},{{immediate:true}}))||scrollTo(0,{int(y)})'); time.sleep(1.8); pg.screenshot(path=f'{OUT}/i-{name}-{k+2}.png')
            pg.evaluate('(window.__lenis&&window.__lenis.scrollTo(document.body.scrollHeight,{immediate:true}))||scrollTo(0,document.body.scrollHeight)'); time.sleep(2.2); pg.screenshot(path=f'{OUT}/i-{name}-ft.png')
            ctx.close()
        ctx, pg = page(390, 844, True)
        for name in ['knyhy', 'zamovyty', 'podarunok', 'pro-nas', 'kontakty']:
            pg.goto(f'{BASE}{name}.html'); time.sleep(3.5); pg.screenshot(path=f'{OUT}/mi-{name}.png')
            pg.evaluate('scrollTo(0, document.querySelector("main > .sec").offsetTop)'); time.sleep(1.5); pg.screenshot(path=f'{OUT}/mi-{name}-2.png')
        ctx.close()
    if what == 'x':
        ctx, pg = page(1440, 900)
        for p in sys.argv[2].split(','):
            idx(pg, p); pg.screenshot(path=f'{OUT}/x-{p}.png')
        ctx.close()
    if what == 'm':
        ctx, pg = page(390, 844, True)
        for p in sys.argv[2].split(','):
            idx(pg, p); pg.screenshot(path=f'{OUT}/mx-{p}.png')
        ctx.close()
    if what == 'pre':
        ctx, pg = page(1440, 900)
        pg.goto(f'{BASE}index.html?pre=1')
        for i in range(8):
            time.sleep(0.6); pg.screenshot(path=f'{OUT}/pre-{i}.png')
        time.sleep(3); pg.screenshot(path=f'{OUT}/pre-after.png')
        ctx.close()
    br.close()
print('LOGS', len(logs)); print('\n'.join(dict.fromkeys(logs)))
