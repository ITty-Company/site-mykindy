// node _notes/test-choreo.mjs — детермінізм і обратимість pose(p), неперервність камери/обкладинки/шарів, SEGS без дір, p=0 і p=1 — книга закрита
import { pose, camera, SEGS, LAYERS, open } from '../public/assets/js/choreo.js';
let fail = 0; const ok = (c, m) => { if (!c) { fail++; console.log('FAIL', m); } };
const N = 4000, S = (p) => JSON.stringify(pose(p), (k, v) => (typeof v === 'number' ? +v.toFixed(6) : v));
const fwd = []; for (let i = 0; i <= N; i++) fwd.push(S(i / N));
let same = true; for (let i = N; i >= 0; i--) if (S(i / N) !== fwd[i]) same = false;
ok(same, 'pose обратима (вперед == назад)');
const p0 = pose(0), p1 = pose(1);
ok(p0.open === 0 && p0.rise.every((r) => r === 0) && p0.kite === 0 && p0.night === 0, 'p=0 — книга закрита, шари складені, день');
ok(p1.open === 0 && p1.rise.every((r) => Math.abs(r) < 1e-9) && p1.kite === 1, 'p=1 — книга закрита, змій над нею');
let mc = 0, mo = 0, mr = 0, pc = camera(0).pos, po = open(0), pr = pose(0).rise;
for (let i = 1; i <= N; i++) { const p = i / N, c = camera(p).pos, o = open(p), r = pose(p).rise; mc = Math.max(mc, Math.hypot(c[0] - pc[0], c[1] - pc[1], c[2] - pc[2])); mo = Math.max(mo, Math.abs(o - po)); r.forEach((v, k) => (mr = Math.max(mr, Math.abs(v - pr[k])))); pc = c; po = o; pr = r; }
ok(mc < 0.5, `камера без ривків (max ${mc.toFixed(3)} см / крок)`);
ok(mo < 0.05, `обкладинка без ривків (max ${mo.toFixed(4)})`);
ok(mr < 0.08, `шари без ривків (max ${mr.toFixed(4)})`);
ok(SEGS[0].t0 === 0 && SEGS.at(-1).t1 === 1 && SEGS.every((s, i) => !i || s.t0 === SEGS[i - 1].t1), 'SEGS без дір');
// пласкі шари не виходять за сторінку (лежать на розвороті)
ok(LAYERS.every((l) => l.z + l.h <= 13.5 + 1e-9 && Math.abs(l.x) + l.hw <= 20.5), 'складені шари в межах розвороту');
console.log(fail ? `${fail} FAIL` : 'choreo OK — обратимо, без ривків, p=0/p=1 — закрита книга');
process.exit(fail ? 1 : 0);
